<?xml version="1.0" encoding="UTF-8"?>
<java version="11.0.10" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1614427359000</long>
      </object>
     </void>
     <void property="message">
      <string>bump year</string>
     </void>
     <void property="revision">
      <string>924de7a6</string>
     </void>
     <void property="tags">
      <string>1.6.4, 1.6.3, 1.6.2, 1.6.1, 1.6.0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1614427338000</long>
      </object>
     </void>
     <void property="message">
      <string>do not create Statistics object unnecessarily</string>
     </void>
     <void property="revision">
      <string>6ef10595</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1614427074000</long>
      </object>
     </void>
     <void property="message">
      <string>report duration for file history cache updates</string>
     </void>
     <void property="revision">
      <string>5752d8ba</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1600984163000</long>
      </object>
     </void>
     <void property="message">
      <string>do not deep copy history entries</string>
     </void>
     <void property="revision">
      <string>d998216b</string>
     </void>
     <void property="tags">
      <string>1.5.12, 1.5.11, 1.5.10, 1.5.9, 1.5.8, 1.5.7, 1.5.6, 1.5.5, 1.5.4, 1.5.3, 1.5.2, 1.5.1, 1.5.0, 1.4.9, 1.4.8, 1.4.7, 1.4.6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1603728702000</long>
      </object>
     </void>
     <void property="message">
      <string>Add copyright part to header check (#3311)
    
    fixes #3300</string>
     </void>
     <void property="revision">
      <string>5d9f3aa0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1585270745000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix #770 Fix #1351 : use PathAccepter in FileHistoryCache
    
    - Extract path-based including/ignoring to configuration
    - Also, relocate Filter, IgnoredDirs, IgnoredFiles,
      IgnoredNames to configuration</string>
     </void>
     <void property="revision">
      <string>40669ece</string>
     </void>
     <void property="tags">
      <string>1.4.5, 1.4.4, 1.4.3, 1.4.2, 1.4.1, 1.4.0, 1.3.16, 1.3.15, 1.3.14, 1.3.13, 1.3.12</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1552358705000</long>
      </object>
     </void>
     <void property="message">
      <string>Handle git-log merge commits and use -m
    
    Also:
    - Add FileHistoryCacheOctopusTest showing dupes
      for merges (before revising for this patch)
    - Update parsing of Git revision with labels
    - Fix #3166 &quot;partial parse of git log&quot;</string>
     </void>
     <void property="revision">
      <string>6a2061fd</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4, 1.3.3, 1.3.2, 1.3.1, 1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5, 1.2.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565687216000</long>
      </object>
     </void>
     <void property="message">
      <string>Add additional checkstyle checks (#2896)</string>
     </void>
     <void property="revision">
      <string>ff44f24a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Lubos Kosco &lt;tarzanek@gmail.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549792004000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge pull request #2633 from ahornace/rename_q
    
    Replace &quot;q&quot; query param name with &quot;full&quot;</string>
     </void>
     <void property="revision">
      <string>895d1b26</string>
     </void>
     <void property="tags">
      <string>1.2.3, 1.2.2, 1.2.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1543636617000</long>
      </object>
     </void>
     <void property="message">
      <string>Support ctags for historical revisions
    
    - Add webappCtags configuration flag, with
      --webappCtags switch, to indicate if the webapp
      is eligible to run ctags.
    - Add Repository.getHistoryGet() override to
      allow sub-classes to override to avoid a full
      in-memory version; and override for Git and
      Mercurial.
    - Revise BoundedBlockingObjectPool as LIFO-to-FIFO
      so the webapp does not start extraneous
      instances; Indexer switches to FIFO performance
      when the queue pool is emptied.
    - make IndexerParallelizer a lazy property of
      RuntimeEnvironment, and make the executors of
      IndexerParallelizer also lazy properties. Move
      the history-related executors into
      IndexerParallelizer so the lifecycle of all
      indexing/history executors are controlled in
      the same class.</string>
     </void>
     <void property="revision">
      <string>e829566c</string>
     </void>
     <void property="tags">
      <string>1.2.0, 1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549029912000</long>
      </object>
     </void>
     <void property="message">
      <string>Add more CheckStyle rules</string>
     </void>
     <void property="revision">
      <string>d1e826fa</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1546136972000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix #2604, add TandemFilename and TandemPath
    
    Also:
    - Do case-insensitive comparison for .gz in
      GZIPAnalyzer.
    - Add a serialVersionUID to silence lint.</string>
     </void>
     <void property="revision">
      <string>4da26a1e</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540591437000</long>
      </object>
     </void>
     <void property="message">
      <string>add argument to generic type, remove redundant cast</string>
     </void>
     <void property="revision">
      <string>35d65303</string>
     </void>
     <void property="tags">
      <string>1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73, 1.1-rc72, 1.1-rc71, 1.1-rc70, 1.1-rc69</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542285408000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge branch &apos;master&apos; into suggester_java9plus_fix</string>
     </void>
     <void property="revision">
      <string>15ce4f35</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540756590000</long>
      </object>
     </void>
     <void property="message">
      <string>updating the log message</string>
     </void>
     <void property="revision">
      <string>72088877</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540756311000</long>
      </object>
     </void>
     <void property="message">
      <string>correct exception type</string>
     </void>
     <void property="revision">
      <string>84a485b5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540755749000</long>
      </object>
     </void>
     <void property="message">
      <string>report a simple message when the historycache does not exist</string>
     </void>
     <void property="revision">
      <string>878a4326</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@oracle.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1533028785000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge remote-tracking branch &apos;upstream/master&apos; into mavenize</string>
     </void>
     <void property="revision">
      <string>6d5300ac</string>
     </void>
     <void property="tags">
      <string>1.1-rc68, 1.1-rc67, 1.1-rc66, 1.1-rc65, 1.1-rc64, 1.1-rc63, 1.1-rc62, 1.1-rc61, 1.1-rc60, 1.1-rc59, 1.1-rc58, 1.1-rc57, 1.1-rc56, 1.1-rc55, 1.1-rc54, 1.1-rc53, 1.1-rc52, 1.1-rc51, 1.1-rc50, 1.1-rc49, 1.1-rc48, 1.1-rc47, 1.1-rc46, 1.1-rc45, 1.1-rc44, 1.1-rc43, 1.1-rc42, 1.1-rc41, 1.1-rc40, 1.1-rc39, 1.1-rc38, 1.1-rc37, 1.1-rc36</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1532960890000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge remote-tracking branch &apos;upstream/master&apos; into mavenize
    
    # Conflicts:
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/analysis/document/TroffAnalyzer.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/analysis/plain/AbstractSourceCodeAnalyzer.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/analysis/plain/PlainAnalyzer.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/analysis/powershell/Consts.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/analysis/swift/Consts.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/history/AccuRevHistoryParser.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/history/ClearCaseHistoryParser.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/history/SCCSHistoryParser.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/index/Indexer.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/web/ProjectHelper.java
    #       opengrok-web/src/main/java/org/opengrok/web/WebappListener.java
    #       opengrok-web/src/test/java/org/opengrok/web/api/v1/controller/SuggesterControllerProjectsDisabledTest.java
    #       opengrok-web/src/test/java/org/opengrok/web/api/v1/controller/SuggesterControllerTest.java</string>
     </void>
     <void property="revision">
      <string>a72324b1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1532780201000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge remote-tracking branch &apos;upstream/master&apos; into mavenize
    
    # Conflicts:
    #       jrcs/pom.xml
    #       opengrok-indexer/pom.xml
    #       opengrok-web/pom.xml
    #       plugins/pom.xml
    #       pom.xml
    #       suggester/pom.xml
    #       tools/ConfigMerge
    #       tools/Groups
    #       tools/OpenGrok</string>
     </void>
     <void property="revision">
      <string>7322be92</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1532269348000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge remote-tracking branch &apos;upstream/master&apos; into mavenize
    
    # Conflicts:
    #       jrcs/pom.xml
    #       opengrok-indexer/pom.xml
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/util/ClassUtil.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/web/SearchHelper.java
    #       opengrok-web/pom.xml
    #       opengrok-web/src/main/java/org/opengrok/web/WebappListener.java
    #       opengrok-web/src/main/java/org/opengrok/web/api/v1/RestApp.java
    #       opengrok-web/src/main/java/org/opengrok/web/api/v1/controller/ConfigurationController.java
    #       opengrok-web/src/main/java/org/opengrok/web/api/v1/controller/ProjectsController.java
    #       opengrok-web/src/main/java/org/opengrok/web/api/v1/controller/SearchController.java
    #       opengrok-web/src/main/java/org/opengrok/web/api/v1/controller/SystemController.java
    #       opengrok-web/src/main/java/org/opengrok/web/api/v1/filter/LocalhostFilter.java
    #       opengrok-web/src/main/webapp/js/utils-0.0.22.js
    #       opengrok-web/src/test/java/org/opengrok/web/api/v1/controller/ConfigurationControllerTest.java
    #       opengrok-web/src/test/java/org/opengrok/web/api/v1/controller/ProjectsControllerTest.java
    #       plugins/pom.xml
    #       pom.xml
    #       web/js/utils-0.0.22.js
    #       web/js/utils-0.0.23.js</string>
     </void>
     <void property="revision">
      <string>911e8af0</string>
     </void>
     <void property="tags">
      <string>1.1-rc35</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1531310725000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge remote-tracking branch &apos;upstream/master&apos; into mavenize
    
    # Conflicts:
    #       README.md
    #       debian/copyright
    #       doc/authorization_howto.txt
    #       doc/groups_howto.txt
    #       jrcs/pom.xml
    #       opengrok-indexer/pom.xml
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/search/Search.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/search/SearchTest.java
    #       opengrok-web/pom.xml
    #       plugins/pom.xml
    #       pom.xml</string>
     </void>
     <void property="revision">
      <string>2e3bfc15</string>
     </void>
     <void property="tags">
      <string>1.1-rc34</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1530713245000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge remote-tracking branch &apos;upstream/master&apos; into mavenize
    
    # Conflicts:
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/web/constraints/PositiveDuration.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/web/constraints/PositiveDurationValidator.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/web/messages/Message.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/web/constraints/PositiveDurationValidatorTest.java
    #       opengrok-web/src/main/java/org/opengrok/web/api/v1/RestApp.java
    #       opengrok-web/src/main/java/org/opengrok/web/constraints/ValidationExceptionMapper.java
    #       src/org/opensolaris/opengrok/web/api/constraints/PositiveDuration.java
    #       src/org/opensolaris/opengrok/web/api/constraints/PositiveDurationValidator.java
    #       src/org/opensolaris/opengrok/web/api/error/ValidationExceptionMapper.java
    #       src/org/opensolaris/opengrok/web/constraints/PositiveDuration.java
    #       src/org/opensolaris/opengrok/web/constraints/PositiveDurationValidator.java
    #       src/org/opensolaris/opengrok/web/constraints/ValidationExceptionMapper.java
    #       test/org/opensolaris/opengrok/web/api/constraint/PositiveDurationValidatorTest.java
    #       test/org/opensolaris/opengrok/web/constraint/PositiveDurationValidatorTest.java</string>
     </void>
     <void property="revision">
      <string>166dc6c0</string>
     </void>
     <void property="tags">
      <string>1.1-rc33, 1.1-rc32, 1.1-rc31</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1530708815000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge remote-tracking branch &apos;upstream/master&apos; into mavenize
    
    # Conflicts:
    #       opengrok-web/src/main/java/org/opengrok/web/AuthorizationFilter.java</string>
     </void>
     <void property="revision">
      <string>9e3bf04c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1530629475000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge remote-tracking branch &apos;upstream/master&apos; into mavenize
    
    # Conflicts:
    #       opengrok-indexer/pom.xml
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/analysis/executables/JavaClassAnalyzer.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/configuration/RuntimeEnvironment.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/configuration/messages/AbortMessage.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/configuration/messages/ConfigMessage.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/configuration/messages/Message.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/configuration/messages/Messages.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/configuration/messages/NormalMessage.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/configuration/messages/ProjectMessage.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/configuration/messages/RefreshMessage.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/configuration/messages/RepositoryMessage.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/configuration/messages/StatsMessage.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/history/SCCSRepositoryAuthorParser.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/index/IndexDatabase.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/index/IndexVersion.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/index/Indexer.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/util/XmlEofInputStream.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/util/XmlEofOutputStream.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/web/PageConfig.java
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/web/Util.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/configuration/RuntimeEnvironmentTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/configuration/messages/AbortMessageTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/configuration/messages/ConfigMessageTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/configuration/messages/ExpirationNormalMessageTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/configuration/messages/MessageTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/configuration/messages/MessagesTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/configuration/messages/NormalMessageTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/configuration/messages/ProjectMessageTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/configuration/messages/RefreshMessageTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/configuration/messages/RepositoryMessageTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/configuration/messages/StatsMessageTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/util/XmlEofInputStreamTest.java
    #       opengrok-indexer/src/test/java/org/opengrok/indexer/util/XmlEofOutputStreamTest.java
    #       opengrok-web/src/main/java/org/opengrok/web/JSONSearchServlet.java
    #       opengrok-web/src/main/webapp/WEB-INF/web.xml
    #       opengrok-web/src/main/webapp/mast.jsp
    #       opengrok-web/src/main/webapp/menu.jspf
    #       opengrok-web/src/main/webapp/repos.jspf
    #       src/org/opensolaris/opengrok/configuration/messages/AbortMessage.java
    #       src/org/opensolaris/opengrok/configuration/messages/RefreshMessage.java
    #       src/org/opensolaris/opengrok/web/api/v1/controller/SystemController.java
    #       src/org/opensolaris/opengrok/web/constraints/ValidationExceptionMapper.java
    #       test/org/opensolaris/opengrok/configuration/messages/RepositoryMessageTest.java
    #       test/org/opensolaris/opengrok/web/api/v1/controller/RepositoriesControllerTest.java
    #       tools/Messages</string>
     </void>
     <void property="revision">
      <string>4ce4e2b9</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1530103612000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge remote-tracking branch &apos;upstream/master&apos; into mavenize
    
    # Conflicts:
    #       nbproject/project.properties
    #       opengrok-web-nbproject/nbproject/project.properties
    #       opengrok-web/src/main/webapp/eforbidden.jsp</string>
     </void>
     <void property="revision">
      <string>1e60c4b2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529684072000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge remote-tracking branch &apos;upstream/master&apos; into mavenize
    
    # Conflicts:
    #       jrcs/pom.xml
    #       opengrok-indexer/pom.xml
    #       opengrok-web/pom.xml
    #       plugins/pom.xml
    #       pom.xml</string>
     </void>
     <void property="revision">
      <string>a03922c4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529596811000</long>
      </object>
     </void>
     <void property="message">
      <string>Merge remote-tracking branch &apos;upstream/master&apos; into mavenize
    
    # Conflicts:
    #       opengrok-indexer/src/main/java/org/opengrok/indexer/index/Indexer.java</string>
     </void>
     <void property="revision">
      <string>5a8ab20b</string>
     </void>
     <void property="tags">
      <string>1.1-rc30</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529594298000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package</string>
     </void>
     <void property="revision">
      <string>9805b761</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529578237000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package – move commit</string>
     </void>
     <void property="revision">
      <string>b5840353</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
