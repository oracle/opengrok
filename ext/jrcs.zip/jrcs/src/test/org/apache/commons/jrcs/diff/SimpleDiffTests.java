package org.apache.commons.jrcs.diff;

public class SimpleDiffTests extends DiffTest {

    public SimpleDiffTests(String name) {
        super(name, new SimpleDiff());
    }


}
